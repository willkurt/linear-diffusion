from setuptools import setup

setup(
    name='linear-diffusion',
    version='0.1',
    packages=['lineardiffusion'],
    url='',
    license='',
    author='Will Kurt',
    author_email='wckurt@gmail.com',
    description='A minimal diffusion model build using only linear models'
)
