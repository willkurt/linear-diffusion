from lineardiffusion.model import *
